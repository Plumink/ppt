#include "Data.h"
#include "DataManage.h"
#include "MGraphFunction.h"

VexPathData vpdataArr[MAX_VERTEX_NUM];

void Initvpdata(VexPathData vpdata)
{
	int i, j;
	for(i = 0; i < MAX_VERTEX_NUM; ++i)
	{
		for(j = 0; j < MAX_VERTEX_NUM; ++j)
		{
			vpdata[i].Shortpath[j] = 0;

		}
		vpdata[i].Distance = 0;
		vpdata[i].Destination = -1;
		vpdata[i].Peoplenum = 0;
		vpdata[i].vex = 0;
	}

}
void InitvpdataArr(VexPathData* vpdataArr)
{
	int i, j;
	for(i = 0; i < MAX_VERTEX_NUM; ++i)
	{
		Initvpdata(vpdataArr[i]);
	}
}

int main(void)
{
	int i,j, sum = 0, allSum[4 * 18]; /* v0ΪԴ�� */
	
	MGraph g;
	PathMatrix p;
	ShortPathTable d;
	VexPathData vpdata;
	int **arrpvex = (int**)malloc(18*4 * sizeof(int *));
	for (i = 0; i < 18*4; i++)
		arrpvex[i] = (int*)malloc(4 * sizeof(int));
	for ( i = 0; i < 18*4; i++)
	{
		for (j = 0; j < 4; j++)
			arrpvex[i][j] = 0;
	}

	
	int pvex[4] = {1,5,12,14};//v2 v6 v13 v15
	CreateUDN(g);
	//PrintG(g);
	//DFSTraverse(g,VisitFunc);
	//printf("\n");
	//�������վ����� arrpvex
	GetALLSiteCombination(arrpvex);
	//��ȡ��ʼ���
	EveryCombinationSites(g, p, d,vpdata, pvex, sum,vpdataArr);
	printf("ԭ����վ���ǣ�V%d  V%d  V%d  V%d       ",g.vexs[pvex[0]],g.vexs[pvex[1]],g.vexs[pvex[2]],g.vexs[pvex[3]]);
	printf("��̾��������ǣ� %d ǧ��*���� \n", sum);
	for(i = 0; i < 4 * 18; ++i)
	{
		pvex[0] = arrpvex[i][0];
		pvex[1] = arrpvex[i][1];
		pvex[2] = arrpvex[i][2];
		pvex[3] = arrpvex[i][3];
		//printf("%d  %d  %d  %d  \n",pvex[0],pvex[1],pvex[2],pvex[3]);
		InitvpdataArr(vpdataArr);
		EveryCombinationSites(g, p, d, vpdata, pvex, sum, vpdataArr);
		allSum[i] = sum;
	}

	int min = INFINITY, k;
	for(i = 0; i < 4 * 18; ++i)
	{
		if(allSum[i] < min)
		{
			min = allSum[i];
			k = i;
		}
	}
	printf("�޸ĺ�վ���ǣ�V%d  V%d  V%d  V%d        ",arrpvex[k][0]+1,arrpvex[k][1]+1,arrpvex[k][2]+1,arrpvex[k][3]+1);
	printf("��̾��������ǣ� %d ǧ��*���� \n", min);
	pvex[0] = arrpvex[k][0];
	pvex[1] = arrpvex[k][1];
	pvex[2] = arrpvex[k][2];
	pvex[3] = arrpvex[k][3];
	InitvpdataArr(vpdataArr);
	EveryCombinationSites(g, p, d, vpdata, pvex, sum, vpdataArr);
	char * fileName = "��Ǩ�����·��.txt";

	OutData(fileName, g, arrpvex, vpdata, allSum[k], k);
	return 0;
}