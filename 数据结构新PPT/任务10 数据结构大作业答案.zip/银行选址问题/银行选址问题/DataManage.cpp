#include "Data.h"
#include "DataManage.h"

int PepleNum[VexNum] = { 50,45,45,48,40,40,36,32,32,30,30,36,25,20,15,20,10,10 };

int k;
void GetSiteShortestPath(MGraph g, PathMatrix &p, ShortPathTable &d, VertexType vex,VexPathData *vpdataArr)
{
	int i,j, v0 = vex;
	// vpdataArr[k]  ��һ���ṹ������ ÿ�������±����һ�����㵽 ��Դ�����
	ShortestPath_DIJ(g,v0,p,d);

	for(i = 0;i < g.vexnum; ++i)
	{
		for(j = 0;j < g.vexnum; ++j)
		{
			if(i != j && p[i][j] == 1)
			{
				vpdataArr[k][i].Shortpath[j] = 1;
			}
		}
		vpdataArr[k][i].vex = g.vexs[i];
		vpdataArr[k][i].Peoplenum = PepleNum[i];
		vpdataArr[k][i].Destination = g.vexs[v0];
	}
	
	for(i = 0;i < g.vexnum;++i)
	{
		vpdataArr[k][i].Distance = d[i];
	}
	++k;
}
void GetAllSiteShortestPath(MGraph g,VexPathData &vpdata,VexPathData *vpdataArr)
{
	int min = INFINITY;
	for(int i = 0;i < g.vexnum;++i)
	{
		vpdata[i].vex = g.vexs[i];
		min = INFINITY;
		for(int n = 0; n < 4; ++n)
			if(vpdataArr[n][i].Distance < min)
			{
				min = vpdataArr[n][i].Distance;
				vpdata[i] = vpdataArr[n][i];
				vpdata[i].Destination = n;
			}
	}
}

void EveryCombinationSites(MGraph g, PathMatrix &p, ShortPathTable &d,VexPathData &vpdata, int *pvex,int &sum,VexPathData *vpdataArr)
{
	int i;
	sum = 0;
	k = 0;
	GetSiteShortestPath( g, p, d, pvex[0],vpdataArr);
	GetSiteShortestPath( g, p, d, pvex[1],vpdataArr);
	GetSiteShortestPath( g, p, d, pvex[2],vpdataArr);
	GetSiteShortestPath( g, p, d, pvex[3],vpdataArr);
	
	GetAllSiteShortestPath(g, vpdata,vpdataArr);
	
	for (i = 0; i < g.vexnum; i++)
	{
		sum += vpdata[i].Distance * vpdata[i].Peoplenum;
	}
}

void GetSiteCombination(VertexType *pvex, int i,int &n, int **arrpvex)
{
	int k , j;
	for (k = 0; k < 18; k++)
	{
		for (j = 0; j < 4; j++)
		{
			if(j == i)
				arrpvex[n][j] = k;
			else
				arrpvex[n][j] = pvex[j];
		}
		++n;
	}
}

void GetALLSiteCombination(int * arrpvex[])
{
	int n = 0;
	
	for (int i = 0; i < 4; i++)
	{
		VertexType pvex[4] = {1,5,12,14};
		GetSiteCombination(pvex, i, n,arrpvex);
	}
	
}

Status OutData(char * fileName,MGraph g,int** arrpvex,VexPathData vpdata,int min,int k)
{
	FILE *fp1 = fopen(fileName ,"w+");

	while(fp1 == NULL)
	{
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	int i,j,n = 0;


	int sum = 0;
	fprintf(fp1,"�޸ĺ�վ��Ϊ��V%d V%d V%d V%d �޸ĺ�ľ����ǣ�%d ǧ��*����\n",g.vexs[arrpvex[k][0]],g.vexs[arrpvex[k][1]],g.vexs[arrpvex[k][2]],g.vexs[arrpvex[k][3]],min);
	for(i = 0; i < 18; ++i)
	{
		if(i < 9)
			fprintf(fp1,"V%d ���",g.vexs[i]);
		else
			fprintf(fp1,"V%d���",g.vexs[i]);

		fprintf(fp1,"�����ǣ� %2d   �����ǣ� %2d  ",vpdata[i].Distance,vpdata[i].Peoplenum);
		fprintf(fp1,"�������㣺",vpdata[i].vex);
		for(int j = 0; j < g.vexnum; ++j)
			if(vpdata[i].Shortpath[j] == 1 && j != arrpvex[k][0] && j != arrpvex[k][1] && j != arrpvex[k][2] && j != arrpvex[k][3])
				fprintf(fp1,"V%d ",j+1);
		fprintf(fp1,"V%d  \n",g.vexs[arrpvex[k][vpdata[i].Destination]]);
		sum += vpdata[i].Distance*vpdata[i].Peoplenum;
	}
	fprintf(fp1,"�ܾ��� = ÿ���ص������ * ÿ���ص�����վ��ľ��� = %d ǧ��*����\n" , sum);
	fclose(fp1);

	return OK;

}
