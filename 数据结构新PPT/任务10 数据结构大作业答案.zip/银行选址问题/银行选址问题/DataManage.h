#ifndef _DataManage_h_
#define _DataManage_h_
#pragma   once   
#include "Data.h"
#include "MGraphFunction.h"

//VexPathData vpdataArr[4];
//int k;
void GetSiteShortestPath(MGraph g, PathMatrix &p, ShortPathTable &d, VertexType vex,VexPathData *vpdataArr);
void GetAllSiteShortestPath(MGraph g,VexPathData &vpdata,VexPathData *vpdataArr);

void EveryCombinationSites(MGraph g, PathMatrix &p, ShortPathTable &d,VexPathData &vpdata, int *pvex,int &sum,VexPathData *vpdataArr);


void GetSiteCombination(VertexType *pvex, int i,int &n, int **arrpvex);
void GetALLSiteCombination(int ** arrpvex);
Status OutData(char * fileName,MGraph g,int** arrpvex,VexPathData vpdata,int min,int k);

#endif
