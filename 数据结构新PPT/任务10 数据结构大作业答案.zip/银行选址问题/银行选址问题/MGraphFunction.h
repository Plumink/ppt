#ifndef _MGraphFunction_h_
#define _MGraphFunction_h_
#include "Data.h"



int LocateVex(MGraph G,char v,int vexnum);

Status CreateUDN(MGraph &G);

void PrintG(MGraph G);

int VisitFunc(MGraph G,int i);

void DFS(MGraph G,int i);

void DFSTraverse(MGraph G,int (* VisitFunc)(MGraph G, int i));

void ShortestPath_DIJ(MGraph G,int v0,PathMatrix &P,ShortPathTable &D);

#endif