#ifndef _GetWeight_h_
#define _GetWeight_h_

#include "Data.h"

Status ReadData(char * fileName,int* weightArr);
Status CompressData(char * fileName);
Status Compressing(char * fileName,WeightType * weight);
int MatchChar(WeightType * weight, char str);
void WriteBit(char *filename,char *ch, int count);
Status DecompressBitData(char * fileName);
void PrintProgress(int i, int n, int *x);
void readBit(char *filename,char **pstr,int &count);


#endif