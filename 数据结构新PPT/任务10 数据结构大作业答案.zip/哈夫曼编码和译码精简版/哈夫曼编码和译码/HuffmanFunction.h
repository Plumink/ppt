#ifndef _HuffmanFuntion_h_
#define _HuffmanFuntion_h_
#include "Data.h"


Status GetWeight(char * fileName,WeightType* Weight);
void Select(HuffmanTree &HT,int x,int &s1,int &s2);
void HuffmanCoding(HuffmanTree &HT,HuffmanCode &HC,int *w,int n);

#endif

