#include "Data.h"
#include "DataManage.h"
#include "huffmanFunction.h"


int main(void)
{
	char *fileName1 = "�����ĵ�.txt";
	char *fileName2 = "�����ĵ�.txt.zip";
	CompressData( fileName1);

	DecompressBitData( fileName2 );
	
	return 0;
}