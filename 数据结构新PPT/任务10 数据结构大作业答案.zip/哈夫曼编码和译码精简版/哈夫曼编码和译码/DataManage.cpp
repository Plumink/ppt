#include "DataManage.h"
#include "HuffmanFunction.h"

Status ReadData(char * fileName,int* weightArr)
{
	FILE *fp = fopen(fileName,"r+");
	int k = -1, size = 0;
	char str = 0;
	while(fp == NULL)
	{
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}

	while(!feof(fp))
	{
		++weightArr[fgetc(fp)];
		++size;
	}
	printf("��ǰ�ļ���%d�ַ���\n", size-1); 
	fclose(fp);
	return OK;
}

Status GetWeight(char * fileName,WeightType* Weight)
{
	int *weightArr = (int *) malloc(MAX_SIZE * sizeof(int));
	
	int i, k = 0;
	for(i = 0; i < MAX_SIZE; ++i)
		weightArr[i] = 0;
	printf("��ȡ��Ҫѹ�����ļ���%s��\n", fileName);
	if(ReadData(fileName, weightArr))
	{
		for(i = 0; i < MAX_SIZE; ++i)
			if(weightArr[i])
			{
				Weight[k].CharData = i;
				Weight[k].Weight = weightArr[i];
				++k;
			}
		
		return OK;
	}
	return ERROR;
}
WeightType weight[MAX_SIZE];
int w[MAX_SIZE];
HuffmanTree HT;
Status CompressData(char * fileName)
{

	HuffmanCode HC;
	int i,n = 0;
	/******************   ��ȡȨֵ   ******************/
	GetWeight(fileName, weight);
	for (i = 0; i < MAX_SIZE; ++i,++n)
	{
		if(weight[i].Weight)
			w[i] = weight[i].Weight;
		else
			break;
	}
	/******************   ��ȡ��ĸ��Ӧ����   ******************/
	HuffmanCoding(HT,HC,w,n);
	for(i = 1;i <= n && w[i-1]; ++i)
		weight[i-1].HuffmanCode = HC[i];

	if(Compressing(fileName, weight) == 0)
		return ERROR;
}
int MatchChar(WeightType * weight, char str)
{
	int i;
	for(i = 0; i < MAX_SIZE && weight->Weight!= 0; ++weight, ++i)
	{
		if(weight->CharData == str)
			return i;
	}
	return -1;
}
Status Compressing(char * fileName, WeightType * weight)
{
	char str = 0,*p = NULL,Arr[2000];
	int Arr_i = 0, pos = -1;
	FILE *fp = fopen(fileName, "r+");
	while(fp == NULL)
	{
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	while(!feof(fp))
	{
		str = fgetc(fp);
		pos = MatchChar(weight, str);
		if(weight[pos].HuffmanCode == NULL)
			;
		else
			for (p = weight[pos].HuffmanCode; *p ; p++)
				Arr[Arr_i++] = *p;
	}
	WriteBit(fileName, Arr, Arr_i);	//���±���0�Ŀռ俪ʼ�ţ��ƶ�����Arr_i-1+1���ַ�
	fclose(fp);
	return OK;
}

int MatchHuffmanCode(WeightType * weight, char *HuffmanCode)
{
	int i;
	for(i = 0; i < MAX_SIZE && weight->Weight!= 0; ++weight, ++i)
	{
		if(!strcmp(weight->HuffmanCode,HuffmanCode))
			return i;
	}
	return -1;
}


void Get01Data(unsigned char N,char *ARR,int &K)
{
	int arr[8] = {0}, kn = 0, i;
	while (N)
	{
		arr[kn++] = N % 2;
		N /= 2;
	}
	for (i = 7; i >= 0; --i)
		ARR[K++] = arr[i];
}
void PrintProgress(int i, int n, int *x)
{
	int y;
	if(*x == i * 10 / n)
	{
		printf("|");
		for(y = 0; y <= *x; y++)
			printf(">");
		for(; y < 10; y++)
			printf("-");
		printf("|�����%d%%\n",(*x+1)*10);
		++*x;
	}
}
void WriteBit(char * fileName, char *ch, int count)
{
	int i, j, num, left,x = 0 ; //num�洢�ַ���Ҫ�Ķ��ٸ��ֽ� 
	char dest, BitFileName[20] = {0};
	FILE *fp = NULL;
	unsigned char *p = NULL; 
	strcat(BitFileName,fileName);
	strcat(BitFileName,".zip");
	if (NULL == (fp = fopen(BitFileName, "wb")))
	{
		printf("�ļ���ʧ��!\n");
		return ;
	}
	num = count / 8;	//�洢�ַ���Ҫ�Ķ��ٸ��ֽ�
	left = count % 8;	//�ַ���ʣ�಻��8λ�ĸ���
	p = (unsigned char *)malloc(sizeof(unsigned char) * (num + (left ? 1 : 0)));
	memset(p, 0, num + (left ? 1 : 0));

	printf("����ѹ��...\n"); 
	j = -1;
	for (i = 0; i < count; i++)//λ���㣬ÿ8���ַ���2���Ƶ���ʽ������һ���ַ��� 
	{
		if (i % 8 == 0)
			j++;

		p[j] <<= 1;     //����1λ  
		ch[i] -= '0';
		p[j] |= ch[i];	//��λ��	
		PrintProgress(j,num + (left ? 1 : 0),&x);
	}
	if (left != 0)	//���left��Ϊ0����Ҫ��ʣ��ļ���λ����߿�£ 
	{
		p[j] <<= 8 - left; //����leftΪ2����00000011����Ҫ����6λ��Ϊ11000000 
		fwrite(&count, sizeof(count), 1, fp);
		fwrite(p, 1, num + 1 , fp);	
	}
	else
	{
		fwrite(&count, sizeof(count), 1, fp);
		fwrite(p, 1, num , fp);	
	}
	printf("ѹ�����ļ�Ϊ��%s��\nѹ�����ļ���%d�ַ���\n \n",BitFileName, num + (left ? 1 : 0)); 
	
	fclose(fp);
}

Status DecompressBitData(char * fileName)
{
	int k = 0, k0 = 0, pos = -1, str = 0,i,n = 0, count, x = 0, ny = 0;
	char* pstr = NULL , ARR[2000], HuffmanCode[MAX_SIZE], fileName0[40] = {0};
	unsigned char flag = 128;
	strcat(fileName0,fileName);
	strcat(fileName0,"��ѹ��.txt");
	FILE *fp = fopen(fileName0 ,"w+");
	while(fp == NULL)
	{
		printf("�ļ���ʧ��!\n");
		return ERROR;
	}
	for (i = 0; i < MAX_SIZE; ++i,++n)
	{
		if(weight[i].Weight)
			w[i] = weight[i].Weight;
		else
			break;
	}
	readBit(fileName, &pstr,count);
	for (i = 0; i < count / 8; i++)
		Get01Data(pstr[i],ARR,k0);
	printf("��ǰ�ļ���%d�ַ���\n", count / 8 + (count % 8 ? 1 : 0));
	printf("���ڽ�ѹ...\n"); 
	for (count = 0; count < k0; )
	{
		i = 2 * n - 1;
		k = 0;
		while (HT[i].lchild)
		{
			str = ARR[count++];
			if(str == 0)
			{
				HuffmanCode[k++] = '0';
				i = HT[i].lchild;
			}
			else if(str == 1)
			{
				HuffmanCode[k++] = '1';
				i = HT[i].rchild;
			}
		}

		HuffmanCode[k] = '\0';
		pos = MatchHuffmanCode(weight, HuffmanCode);
		fprintf(fp,"%c",weight[pos].CharData);
		++ny;
		PrintProgress(count,k0,&x);
	}
	printf("��ѹ���ļ�Ϊ��%s��\nѹ�����ļ���%d�ַ���\n", fileName0, ny); 
	fclose(fp);
	return OK;
}

void readBit(char* filename,char **pstr,int &count)
{
	int num, left, i;
	FILE *fp = fopen(filename, "rb");
	if (fp == NULL)
	{
		printf("�ļ���ʧ��!\n");
		return ;
	}
	
	fread(&count, sizeof(count), 1, fp);
	num = count / 8;
	left = count % 8;
	
	if (left == 0)
	{
		*pstr = (char *)malloc(sizeof(char) * num);
		fread(*pstr, 1, num, fp);
	}
	else
	{
		*pstr = (char *)malloc(sizeof(char) * (num + 1));
		fread(*pstr, 1, num + 1, fp);
	}
	printf("��ȡ��Ҫ��ѹ���ļ���%s��\n", filename);
	fclose(fp);
}

